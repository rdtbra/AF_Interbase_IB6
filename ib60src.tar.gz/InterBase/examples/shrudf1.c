/*
 *	PROGRAM:	Examples
 *	MODULE:		shrudf.c
 *	DESCRIPTION:	Imported symbol initialization for shared UDF library
 *
 * The contents of this file are subject to the Interbase Public
 * License Version 1.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy
 * of the License at http://www.Inprise.com/IPL.html
 *
 * Software distributed under the License is distributed on an
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express
 * or implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code was created by Inprise Corporation
 * and its predecessors. Portions created by Inprise Corporation are
 * Copyright (C) Inprise Corporation.
 *
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

#include <time.h>
#include <sys/types.h>
/*
int (*_libfun_strcmp)() = 0;
int (*_libfun_sprintf)() = 0;
time_t (*_libfun_time)() = 0;
char *(*_libfun_ctime)() = 0;
char *(*_libfun_strcpy)() = 0;
int (*_libfun_strlen)() = 0;
*/
